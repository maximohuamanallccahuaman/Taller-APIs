package model;

import java.io.Serializable;
import lombok.Data;

@Data
public class Pais implements Serializable{
    
    //Pais
//    String confirmado;
//    String recuperado;
//    String muerto;
    String pais;
//    String poblacion;
//    String area;
//    String vida;
//    String mar;
    String continente;
//    String abreviatura;
//    String locacion;
//    String capital;
    
}
